#include "MoveCursor.h"
#include "Command.h"
#include <iostream>

void MoveCursorObserver::Update()
{

}
